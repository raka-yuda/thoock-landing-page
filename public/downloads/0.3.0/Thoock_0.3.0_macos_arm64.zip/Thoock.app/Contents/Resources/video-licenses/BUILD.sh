#!/usr/bin/env bash
# Build from pinned upstream source. No third-party prebuilt executable downloads.
set -Eeuo pipefail
stage='initializing'
report_failure() {
  local status=$?
  trap - ERR
  set +e
  printf '\nVideo tools failed during %s (target: %s, exit: %s).\n' "$stage" "${target:-unknown}" "$status" >&2
  if [ -n "${cache:-}" ]; then
    # Preserve configure's detailed compiler checks even when make fails.
    if [ -f "$cache/ffmpeg-$version/ffbuild/config.log" ]; then
      cp "$cache/ffmpeg-$version/ffbuild/config.log" "$cache/config.log"
    fi
    for log in configure.log config.log build.log; do
      if [ -f "$cache/$log" ]; then
        printf '\nLast 120 lines of %s:\n' "$cache/$log" >&2
        tail -n 120 "$cache/$log" >&2
      fi
    done
  fi
  exit "$status"
}
trap report_failure ERR
root="$(cd "$(dirname "$0")/.." && pwd)"
version=9.0.2
sha=8c3850283eb25fa026482078a04051e0be17347b09ef81a0849bec15a96e002e
case "$(uname -s)" in
 Darwin) target=aarch64-apple-darwin; suffix=; extra=(--enable-videotoolbox --extra-cflags=-mmacosx-version-min=11.0 --extra-ldflags=-mmacosx-version-min=11.0); jobs=4;;
 MINGW*|MSYS*) target=x86_64-pc-windows-msvc; suffix=.exe; extra=(--enable-mediafoundation --enable-d3d11va --cc=gcc --extra-ldflags=-static); jobs=4;;
 *) echo 'Supported builds: macOS arm64 or Windows x64 in MSYS2 UCRT64.' >&2; exit 1;;
esac
out="$root/src-tauri/binaries"
cache="$root/src-tauri/target/video-tools-$target"
mkdir -p "$cache" "$out" "$root/src-tauri/video-licenses"
archive="$cache/ffmpeg-$version.tar.xz"
stage='downloading and verifying source'
if [ ! -f "$archive" ]; then curl --fail --location --proto '=https' "https://ffmpeg.org/releases/ffmpeg-$version.tar.xz" -o "$archive"; fi
if command -v sha256sum >/dev/null; then actual=$(sha256sum "$archive" | cut -d' ' -f1); else actual=$(shasum -a 256 "$archive" | cut -d' ' -f1); fi
[ "$actual" = "$sha" ] || { echo 'FFmpeg source checksum mismatch' >&2; exit 1; }
if [ ! -f "$cache/ffmpeg-$version/configure" ]; then tar -xf "$archive" -C "$cache"; fi
cd "$cache/ffmpeg-$version"
stage='configuring FFmpeg'
./configure --disable-autodetect --disable-network --disable-doc --disable-debug --disable-shared --enable-static --disable-x86asm --disable-programs --enable-ffmpeg --enable-ffprobe --disable-everything --enable-avcodec --enable-avformat --enable-avfilter --enable-swscale --enable-swresample --enable-protocol=file --enable-demuxer=mov,matroska,avi,mpegts,image2 --enable-decoder=h264,hevc,prores,mpeg4,mjpeg,vp8,vp9,av1 --enable-parser=h264,hevc,mpeg4video,vp8,vp9,av1 --enable-encoder=mjpeg,h264_videotoolbox,h264_mf --enable-muxer=image2,mov,mp4,avi --enable-filter=scale,format,setsar,transpose,hflip,vflip,null --enable-bsf=h264_mp4toannexb,hevc_mp4toannexb "${extra[@]}" > "$cache/configure.log" 2>&1
stage='compiling and linking FFmpeg'
make -j "$jobs" ffmpeg"$suffix" ffprobe"$suffix" > "$cache/build.log" 2>&1
stage='packaging video tools'
for name in ffmpeg ffprobe; do cp "$name$suffix" "$out/$name-$target$suffix"; done
cp "$archive" "$root/src-tauri/video-licenses/ffmpeg-$version-source.tar.xz"
cp "$root/scripts/prepare-video-tools.sh" "$root/src-tauri/video-licenses/BUILD.sh"
cp COPYING.LGPLv2.1 "$root/src-tauri/video-licenses/COPYING.LGPLv2.1"
cp ffbuild/config.log "$cache/config.log"
printf 'FFmpeg %s\nSource: https://ffmpeg.org/releases/ffmpeg-%s.tar.xz\nSHA256: %s\nBuilt using scripts/prepare-video-tools.sh; GPL and nonfree components are disabled.\n' "$version" "$version" "$sha" > "$root/src-tauri/video-licenses/NOTICE.txt"
if command -v sha256sum >/dev/null; then sha256sum "$root/scripts/prepare-video-tools.sh" | cut -d' ' -f1 > "$out/build-input.sha256"; else shasum -a 256 "$root/scripts/prepare-video-tools.sh" | cut -d' ' -f1 > "$out/build-input.sha256"; fi
echo "Prepared video tools for $target"
